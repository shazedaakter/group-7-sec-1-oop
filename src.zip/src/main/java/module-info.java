module org.example.sec1group7 {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.sec1group7 to javafx.fxml;
    exports org.example.sec1group7;
}