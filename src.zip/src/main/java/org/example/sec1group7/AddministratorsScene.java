package org.example.sec1group7;

public class AddministratorsScene
{
    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void quizzestextfield(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void progresstrackingtextfield(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void logoutbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void createbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void backbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void feedbacktextfield(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void reloadbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void lessonplanningtexedfiled(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void submitbuttononclick(ActionEvent actionEvent) {
    }
}