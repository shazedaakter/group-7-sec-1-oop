package org.example.sec1group7;

public class ChildEnrollCoursesScene
{
    @javafx.fxml.FXML
    private TableColumn datecol;
    @javafx.fxml.FXML
    private TableColumn namecol;
    @javafx.fxml.FXML
    private TableColumn emailcol;
    @javafx.fxml.FXML
    private TableView examnotificationtable;
    @javafx.fxml.FXML
    private TableColumn timecol;
    @javafx.fxml.FXML
    private TableColumn deadline;
    @javafx.fxml.FXML
    private TableColumn coursescol;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void logoutbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void backbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void reloadbuttononclick(ActionEvent actionEvent) {
    }
}