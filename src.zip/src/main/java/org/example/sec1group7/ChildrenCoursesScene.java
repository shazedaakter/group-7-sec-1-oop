package org.example.sec1group7;

public class ChildrenCoursesScene
{
    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void reloadbuttonclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void backbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void logoutbutonclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void nametextfield(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void submitbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void idtext(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void coursenametextfield(ActionEvent actionEvent) {
    }
}