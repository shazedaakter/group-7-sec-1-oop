package org.example.sec1group7;

public class CorporateClientsScene
{
    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void communicationskillsbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void logoutbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void backbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void reloadbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void businessenglishbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void workenvironmentbuttononclick(ActionEvent actionEvent) {
    }
}