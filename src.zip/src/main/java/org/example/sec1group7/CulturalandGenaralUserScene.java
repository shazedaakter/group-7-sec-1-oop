package org.example.sec1group7;

public class CulturalandGenaralUserScene
{
    @javafx.fxml.FXML
    private TextField textfield;

    @javafx.fxml.FXML
    private ChoiceBox <String>combolist;

    @Deprecated
    public void initialize(URl url, ResourceBundle resourcebundle) {

        Observallist<String>list=FXCollection.observableAeeayList( "Video","Vlog","Articles","Asian Cultural");
              chkCombo.setItems(list);
    }
   @fxml
   voidInputToCombobox(Actionevent event)


    @Deprecated
    public void Articales(Event event) {
    }

    @javafx.fxml.FXML
    public void getcomboboxbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void Articles(Event event) {
    }

    @javafx.fxml.FXML
    public void Video(Event event) {
    }

    @javafx.fxml.FXML
    public void Vlog(Event event) {
    }

    @javafx.fxml.FXML
    public void Submitbuttononclick(ActionEvent actionEvent) {
    }

    @Deprecated
    public void vlog(Event event) {
    }

    @Deprecated
    public void video(Event event) {
    }

    @javafx.fxml.FXML
    public void fxid(Event event) {
    }
}