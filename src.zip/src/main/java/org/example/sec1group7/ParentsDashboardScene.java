package org.example.sec1group7;

public class ParentsDashboardScene
{
    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void childrenenrollcoursesorexamsbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void coursescapacitybuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void schedulebuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void prerequistesbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void descriptionbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void studyforcounselingabroadbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void parentsteachermeetingbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void childperformancereportbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void communicationwithinstructorbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void applyforscholarshipforchildbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void payexamortutionfeebuttononclick(ActionEvent actionEvent) {
    }
}