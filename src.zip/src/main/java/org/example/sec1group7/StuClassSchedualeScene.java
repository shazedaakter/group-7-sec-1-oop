package org.example.sec1group7;

public class StuClassSchedualeScene
{
    @javafx.fxml.FXML
    private TableColumn classroomnumcol;
    @javafx.fxml.FXML
    private TableColumn datecol;
    @javafx.fxml.FXML
    private TableColumn coursenamecol;
    @javafx.fxml.FXML
    private TableColumn classlinkcol;
    @javafx.fxml.FXML
    private TableView studentclassroutinetable;
    @javafx.fxml.FXML
    private TableColumn classtimecol;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void backbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void reloadbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void logoutbuttonclick(ActionEvent actionEvent) {
    }
}