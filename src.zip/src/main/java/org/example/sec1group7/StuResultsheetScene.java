package org.example.sec1group7;

public class StuResultsheetScene
{
    @javafx.fxml.FXML
    private TableView studentresultsheettable;
    @javafx.fxml.FXML
    private TableColumn numcol;
    @javafx.fxml.FXML
    private TableColumn idcol;
    @javafx.fxml.FXML
    private TableColumn cgpacol;
    @javafx.fxml.FXML
    private TableColumn coursescol;
    @javafx.fxml.FXML
    private TableColumn gradecol;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void logoutbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void backbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void reloadebuttononclick(ActionEvent actionEvent) {
    }
}