package org.example.sec1group7;

public class StudentDashboardScene
{
    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void resultbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void classessbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void addminitratorsandstaffbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void corporateclientloginbuttononclick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void culturalandgenaraluserbuttononclick(ActionEvent actionEvent) {
    }
}